# import streamlit as st

# def show_login_page():
#     st.title("Login Page")

#     # Predefined credentials (for simplicity, use a database in production)
#     valid_user = "admin"
#     valid_pass = "password123"

#     # Login form
#     with st.form("login_form"):
#         username = st.text_input("Username")
#         password = st.text_input("Password", type="password")
#         submitted = st.form_submit_button("Login")

#         if submitted:
#             if username == valid_user and password == valid_pass:
#                 st.session_state["logged_in"] = True  # Set session state to logged in
#                 st.success("Login Successful!")
#                 st.rerun()  # Re-run the app to redirect to the main dashboard
#             else:
#                 st.error("Invalid Username or Password!")

# # Check login state
# if "logged_in" not in st.session_state or not st.session_state.logged_in:
#     show_login_page()  # Show login page if not logged in
# else:
#     import main_dashboard  # Import main_dashboard.py to start the main app
#     main_dashboard.show_dashboard()  # Assuming you have a `show_dashboard` function in main_dashboard.py


# login.py
# login.py


import streamlit as st
import main_dashboard

# Function to render the login page
def login_page():
    # Check if user is already logged in
    if "logged_in" not in st.session_state or not st.session_state.logged_in:
        # If not logged in, show login form
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        # Button to submit the login form
        if st.button("Login"):
            # Simplified check for login (replace with your actual authentication logic)
            if username == "admin" and password == "admin":  # Example credentials
                st.session_state.logged_in = True  # Store login status in session state
                st.session_state.username = username  # Store username
                st.write("Login successful!")
                main_dashboard.main_dashboard()  # Show the main dashboard after login
            else:
                st.write("Invalid credentials. Please try again.")
    else:
        # If already logged in, show the main dashboard directly
        main_dashboard.main_dashboard()

# Run the login page
if __name__ == "__main__":
    login_page()

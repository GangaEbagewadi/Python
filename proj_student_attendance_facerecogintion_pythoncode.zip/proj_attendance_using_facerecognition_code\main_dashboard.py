# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app

# from analytical_graph import run_analytical_graph_app

# #from timetable_academic_calendar import run_timetable_calendar_app  # Corrected import

# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Sidebar navigation
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Navigation", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from visual_graph.py
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from timetable_academic_calendar.py

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()


# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app

# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py for attendance
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app

# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py for attendance
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
# from database import load_attendance_from_db, save_attendance_to_db
# import datetime
# import calendar


# # Function to render the main dashboard
# def main_dashboard():
#     # Initialize current_year and current_month in session_state if not already present
#     if 'current_year' not in st.session_state:
#         st.session_state.current_year = datetime.datetime.now().year  # Set the current year
#     if 'current_month' not in st.session_state:
#         st.session_state.current_month = datetime.datetime.now().month  # Set the current month

#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             # Here we load attendance for the current month
#             year = st.session_state.current_year
#             month = st.session_state.current_month
#             df = load_attendance_from_db(year, month)  # Fetch attendance data from the database
#             run_attendance_app()  # Pass the attendance dataframe to your attendance app for rendering
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

# import streamlit as st

# # import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
# # from database import load_attendance_from_db, save_attendance_to_db

# import calendar
# import pandas as pd
# from datetime import datetime
# from database import create_attendance_df, save_attendance_to_db, load_attendance_from_db, update_attendance_in_db

# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             render_attendance_section()  # Function to handle attendance

#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details

#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications

#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs

#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Function to handle the Attendance section
# def render_attendance_section():
#     # Select year and month for attendance tracking
#     year = st.selectbox("Select Year", [2023, 2024])
#     month = st.selectbox("Select Month", list(range(1, 13)))

#     # Create the empty DataFrame or load existing data from DB
#     if st.button("Load Attendance Data"):
#         df = load_attendance_from_db(year, month)
#         if not df.empty:
#             st.write(f"Attendance data for {calendar.month_name[month]} {year}:")
#             st.dataframe(df)
#         else:
#             st.write("No attendance data available for this month.")

#     # Adding or editing attendance
#     st.subheader("Update Attendance")
#     student_name = st.text_input("Student Name")
#     usn = st.text_input("USN")
#     date = st.selectbox("Select Date", [datetime(year, month, day).strftime('%a, %d') for day in range(1, 32) if day <= calendar.monthrange(year, month)[1]])

#     status = st.radio("Select Status", ["Present", "Absent", "Leave"])

#     # Update attendance when user submits
#     if st.button("Update Attendance"):
#         if student_name and usn and date and status:
#             update_attendance_in_db(df, student_name, date, status)
#             st.success(f"Attendance for {student_name} on {date} updated to {status}.")
#         else:
#             st.error("Please fill all fields!")

#     # Option to download attendance data as Excel file
#     if st.button("Download Attendance as Excel"):
#         if not df.empty:
#             filename = f"attendance_{year}_{month}.xlsx"
#             df.to_excel(filename, index=False)
#             st.download_button(
#                 label="Download Excel File",
#                 data=df.to_excel(index=False),
#                 file_name=filename,
#                 mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
#             )
#         else:
#             st.write("No data to download. Please load or enter attendance data first.")

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
# from database import load_attendance_from_db, save_attendance_to_db  # Import functions from database.py

# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             year = st.session_state.current_year
#             month = st.session_state.current_month
#             # Load attendance data from the database
#             df = load_attendance_from_db(year, month)  # Fetch attendance data
#             run_attendance_app(df)  # Pass the dataframe to the attendance app
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

#from database import load_attendance_from_db, save_attendance_to_db 
# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
 

# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py for attendance
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()


# import streamlit as st
# from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
# from firebase_database import mark_attendance, get_attendance, get_attendance_by_date


# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py for attendance
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

# main_dashboard.py

# import streamlit as st
# from attendance import attendance_app

# #from attendance import run_attendance_app
# from student_details import run_student_details_app
# from notifications import run_notifications_app
# from academic_calendar import run_timetable_calendar_app
# from analytical_graph import run_analytical_graph_app
# #from firebase_database import mark_attendance, get_attendance, get_attendance_by_date


# # Function to render the main dashboard
# def main_dashboard():
#     # Check if the user is logged in
#     if "logged_in" not in st.session_state or not st.session_state.logged_in:
#         st.write("Please login first!")
#     else:
#         # Display a welcome message
#         st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

#         # Sidebar navigation options
#         pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
#         page = st.sidebar.selectbox("Select a section", pages)

#         # Render the selected page
#         if page == "Attendance":
#             run_attendance_app()  # Function from attendance.py for attendance
#         elif page == "Student Details":
#             run_student_details_app()  # Function from student_details.py for student details
#         elif page == "Notifications":
#             run_notifications_app()  # Function from notifications.py for notifications
#         elif page == "Analytics":
#             run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
#         elif page == "Timetable and Calendar":
#             run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# # Run the main dashboard
# if __name__ == "__main__":
#     main_dashboard()

import streamlit as st

from attendance import run_attendance_app

# Now you can call attendance_app() when needed

  
#from attendance import attendance_app
from student_details import run_student_details_app
from notifications import run_notifications_app
from academic_calendar import run_timetable_calendar_app
from analytical_graph import run_analytical_graph_app

# Function to render the main dashboard
def main_dashboard():
    # Check if the user is logged in
    if "logged_in" not in st.session_state or not st.session_state.logged_in:
        st.write("Please login first!")
    else:
        # Display a welcome message
        st.write(f"Welcome to the Student Attendance System Dashboard, {st.session_state.username}!")

        # Sidebar navigation options
        pages = ["Attendance", "Student Details", "Notifications", "Analytics", "Timetable and Calendar"]
        page = st.sidebar.selectbox("Select a section", pages)

        # Render the selected page
        if page == "Attendance":
            run_attendance_app()  # Function from attendance.py for attendance
        elif page == "Student Details":
            run_student_details_app()  # Function from student_details.py for student details
        elif page == "Notifications":
            run_notifications_app()  # Function from notifications.py for notifications
        elif page == "Analytics":
            run_analytical_graph_app()  # Function from analytical_graph.py for analytics and graphs
        elif page == "Timetable and Calendar":
            run_timetable_calendar_app()  # Function from academic_calendar.py for timetable/calendar

# Run the main dashboard
if __name__ == "__main__":
    main_dashboard()


